<?php
namespace app\common\model;

class AuthGroupAccess extends Base
{
    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;
}