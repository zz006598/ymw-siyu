<?php
namespace addons\payment\controller;

use think\facade\Request;
use think\facade\View;
use Yurun\PaySDK\AlipayApp\FTF\Params\ExtendParams;

class Alipay
{
    // 当面付
    public function qr()
    {

    }
}