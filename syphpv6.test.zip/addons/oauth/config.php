<?php

return array (
  'appid' => 
  array (
    'title' => 'APPID：',
    'type' => 'text',
    'options' => 
    array (
    ),
    'value' => '101907301',
  ),
  'appkey' => 
  array (
    'title' => 'APPKEY：',
    'type' => 'text',
    'options' => 
    array (
    ),
    'value' => '170aae41edaf63da8f5fc519f646d80f',
  ),
  'callbackUrl' => 
  array (
    'title' => '回调地址：',
    'type' => 'text',
    'value' => 'http://www.syphpv6.test/addons/oauth/index/callback.html',
  ),
);
