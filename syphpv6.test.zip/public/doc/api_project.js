define({
  "name": "SIYUCMS",
  "version": "6.0.0",
  "description": "api接口",
  "title": "SIYUCMS V6 API接口",
  "url": "http://tp6.com/api",
  "header": {
    "title": "SIYUCMS",
    "filename": ""
  },
  "template": {
    "withCompare": true,
    "withGenerator": false
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-11-05T01:25:40.264Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
