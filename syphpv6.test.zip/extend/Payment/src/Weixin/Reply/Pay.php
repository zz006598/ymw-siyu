<?php
namespace Yurun\PaySDK\Weixin\Reply;

/**
 * 微信支付-回复支付通知基类
 */
class Pay extends Base
{
}